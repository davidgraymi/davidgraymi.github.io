# tetris-ai
A repo that houses a custom tetris game in python with a deep reinforcement learning model to play.

In this project, we propose to use Q-learning and memory replay with a reward function to train a Deep Q-Network (DQN) agent using reinforcement learning to play Tetris. The agent will be trained to rotate and position unique falling shapes to make a consecutive row of blocks therefore removing that row ensuring the game does not end. The agent will have to not only understand the fundamentals but also set itself up for success in future situations the game presents.